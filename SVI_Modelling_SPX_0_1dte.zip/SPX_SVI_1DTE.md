# Short‑Dated SPX Implied Volatility – Write‑up

## 1. Assumptions

- **Forward price**: Synthetic spot from the pipeline is used, adjusted by the 10‑year Treasury yield (4.5%) and zero dividend yield. For 1‑day expiry, this is a realistic proxy.
- **Risk‑free rate**: 4.5% – a reasonable value for the 10‑year Treasury on 2026‑01‑15.
- **Black‑76 model**: Appropriate for European cash‑settled options on a forward.
- **Out‑of‑the‑money options only**: Calls with strike > forward, puts with strike < forward. This avoids illiquid in‑the‑money quotes and reduces noise.
- **SVI parameter bounds**: \(b \ge 0\), \(|\rho| < 1\), \(\sigma \ge 0\) – prevent obvious arbitrage shapes.

## 2. Choices and reasoning

- **Date & expiry**: 2026‑01‑15 → 2026‑01‑16 (1 DTE). Midday snapshot (12:00 ET) balances liquidity and stability. 1 DTE avoids the extreme curvature of 0DTE and the lower liquidity of 2DTE.
- **Underlying SPXW**: I used SPXW for 1 DTE because the data notes that 0 DTE is SPXW only; for 1 DTE both SPX and SPXW trade, but SPXW is the PM‑settled, more actively traded contract for very short dates.
- **SVI fitting**: Least‑squares minimisation with bounds. The standard SVI form is flexible enough to capture the typical equity skew.
- **Arbitrage check**: Butterfly (static) arbitrage is tested by evaluating the second derivative of call prices derived from the SVI fit. A dense strike grid and finite differences are used.

## 3. Results

The fitted SVI parameters (total variance \(w(k) = a + b(\rho(k-m) + \sqrt{(k-m)^2+\sigma^2})\)) are:

| Parameter | Value     |
|-----------|-----------|
| a         | -0.001431 |
| b         | 0.018732  |
| ρ         | -0.175986 |
| m         | -0.006947 |
| σ         | 0.079119  |

The negative ρ confirms a downward‑sloping skew (puts more expensive than calls). The RMSE between market implied volatilities and SVI‑fitted IVs is **0.002560**, indicating a very good fit.

**Butterfly arbitrage check**: The second derivative of the call price with respect to strike was non‑negative across all strikes (minimum > -1e-6). Hence the fitted SVI smile is free of static butterfly arbitrage.

## 4. Limitations

- **Missing bid/ask spreads**: Using `close` prices may introduce bias, especially for far‑OTM strikes.
- **Single snapshot**: Liquidity varies minute‑by‑minute.
- **SVI does not guarantee convexity**: Although I tested convexity, the fit itself did not enforce it. A more conservative approach would use SSVI.
- **Short maturity**: Total variance is extremely small (~0.002–0.01), making the optimisation sensitive to small pricing errors.

## 5. Next steps (if time permitted)

- **Alternative models**: Test a quadratic in log‑moneyness or the SSVI (Surface SVI) which enforces no‑arbitrage by construction.
- **Volume‑weighted average price (VWAP)**: Use `(high+low+close)/3` weighted by volume to reduce microstructure noise, rather than relying solely on the `close` price.

## 6. Conclusion

I successfully constructed a 1‑DTE SPXW implied volatility smile, derived the forward using a 10‑year Treasury yield, fitted an SVI to total variance, and verified the absence of butterfly arbitrage. The SVI captures the negative skew well, and the low RMSE confirms a good fit. The stretch arbitrage check adds confidence that the smile is consistent with no‑static‑arbitrage.